#ifndef PROTOCOL_SERVER_H_
#define PROTOCOL_SERVER_H_
#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
#endif
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#define BUFFERSIZE 512
#define PROTOPORT 27015 // default protocol port number
#define localhost "127.0.0.1"
#define QLEN 5 // size of request queue


void ErrorHandler(char *errorMessage) {
		printf(errorMessage);
	}
	void ClearWinSock() {
	#if defined WIN32
		WSACleanup();
	#endif
	}

	int main(int argc, const char**argv) {  //Start Main
		int port=PROTOPORT;
		if (port < 0) {
			printf("\nBad port number %s \n", port);
		}
		#if defined WIN32 // Inizialization Winsock library
		WSADATA wsaData;
		int iResult = WSAStartup(MAKEWORD(2,2), &wsaData);
		if (iResult != 0) {
			ErrorHandler("Error at WSAStartup()\n");
				return 0;
		}
		#endif

		/* Creation of the socket */
		int MySocket;
		MySocket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
		if (MySocket < 0) {
			ErrorHandler("Failure of socket creation\n");
			ClearWinSock();
			return 0;
		}

		/*Port assignment to socket */
		struct sockaddr_in sad;
		memset(&sad, 0, sizeof(sad)); // ensures that extra bytes contain 0
		sad.sin_family = AF_INET;
		sad.sin_addr.s_addr = inet_addr("127.0.0.1");
		sad.sin_port = htons(port);

		if (bind(MySocket, (struct sockaddr*) &sad, sizeof(sad)) < 0) {
			ErrorHandler("Binding failed!\n");
			closesocket(MySocket);
			ClearWinSock();
			return 0;
		}

		/* Setting of the listening socket */
		if (listen (MySocket, QLEN) < 0) {
			ErrorHandler("Setup of listening socket failed\n");
			closesocket(MySocket);
			ClearWinSock();
			return 0;
		}


		/* Accept new connection */
		struct sockaddr_in cad; // structure for the client address
		int clientSocket; // socket descriptor for the client
		int clientLen; // the size of the client address
		printf("Server \n\n Waiting for client...");
		while (1) { //Start While1
			clientLen = sizeof(cad); // set the size of the client address
			if ((clientSocket = accept(MySocket, (struct sockaddr *)&cad, &clientLen)) < 0) {
				ErrorHandler("failed new connection!.\n");
				closesocket(MySocket);
				ClearWinSock();
				return 0;
			}
			printf("\n\nconnection established: %s : %d \n", inet_ntoa(cad.sin_addr), htons(cad.sin_port));



			char mess[BUFFERSIZE]="connection established";
			int stringLen = sizeof(mess); // determine the length
			send(clientSocket, mess, stringLen, 0);
}
		system("PAUSE");
				return(0);

	}
#endif /* PROTOCOL_SERVER_H_ */
