#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
#endif
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#define PROTOPORT 27015 // default protocol port number
#define QLEN 5 // size of request queue
#define localhost "127.0.0.1"
#define BUFFERSIZE 512


/*global variables*/
		char operation[BUFFERSIZE];
		int x;
		int y;
		int result;


/* function prototypes */

int add(int x, int y);
int sub(int x, int y);
int mult(int x, int y);
int division(int x, int y);


void ErrorHandler(char* errorMessage);
void clearWinSock();
void welcomeMessage();


int main (int argc, const char** argv){
	welcomeMessage();
	int port = PROTOPORT;
	if (port < 0){
		printf("\nBad port number %d", port);
	}

#if defined WIN32
	WSADATA wsaData;
	int iResult = WSAStartup(MAKEWORD(2,2), &wsaData);
	if(iResult != 0){
		ErrorHandler("\nWSAStartup () initialization error!");
		system("Pause");
		return 0;
	} else {
		printf("[+] WSAStartup initialization successful!\n");
	}
#endif


	/* Creation of the socket */

	int mySocket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (mySocket < 0){
		ErrorHandler("Failure of socket creation!\n");
		clearWinSock();
		return 0;
	} else printf("[+] Socket created successfully\n");

	/* End creation of the socket */


	/*Port assignment to socket */

	struct sockaddr_in myaddr;
	memset(&myaddr, 0, sizeof(myaddr));
	myaddr.sin_family = AF_INET;
	myaddr.sin_addr.s_addr = inet_addr(localhost);
	myaddr.sin_port = htons(port);

	if (bind(mySocket, (struct sockaddr*)&myaddr, sizeof(myaddr))<0){
		ErrorHandler("Binding failed!\n");
		closesocket(mySocket);
		clearWinSock();
		system("Pause");
		return 0;
	} else printf("[+] Binding successfully!\n");

	/* End assignment */

	/* Setting of the listening socket */

	if (listen(mySocket, QLEN) < 0){
		ErrorHandler("Setup of listening socket failed\n");
		closesocket(mySocket);
		clearWinSock();
		system("Pause");
		return -1;
	} else printf ("[+] Socket set correctly. socket in listening!\n");

	/* End of socket setting */

	/* Accept new connection */
	struct sockaddr_in cad;
	int clientSocket;
	int clientLen;

	printf("\n Waiting for client... \n");

	while(1){

		clientLen = sizeof(cad);
		if((clientSocket = accept (mySocket, (struct sockaddr*)&cad, &clientLen))<0){
			ErrorHandler("failed new connection!");
			closesocket(mySocket);
			clearWinSock();
			system("Pause");
			return -1;
		}

		/*printf("INFO CLIENT");
		printf("\n\tConnection established with: %s", inet_ntoa(cad.sin_addr));
		struct hostent* host = gethostbyaddr((char*)&cad.sin_addr, sizeof(cad.sin_addr), AF_INET);
		printf("\n\tName client: %s\n", host->h_name);
		printf("Client Port: %hu\n", ntohs(cad.sin_port));*/
		printf("Connection established with %s: %hu\n", inet_ntoa(cad.sin_addr), ntohs(cad.sin_port));

		char* messageToClient = "connection successfully";// String to send to the client
		if(send(clientSocket, messageToClient, strlen(messageToClient), 0) <= 0){
			ErrorHandler("\n error send message! ");
			closesocket(mySocket);
			clearWinSock();
			system("Pause");
			return 0;
		}

		char operation[BUFFERSIZE];

		if(recv(clientSocket, operation, BUFFERSIZE, 0) <= 0){
			printf("Error receive operation\n");
			closesocket(mySocket);
			clearWinSock();
			system("Pause");
			return 0;
		}

		else{
			printf("correct operation: %s\n", operation);
		}
		char* messageAdd = "ADDITION";
		char* messageSottr = "SUBTRACTION";
		char* messageMolt = "MULTIPLICATION";
		char* messageDivis = "DIVISION";
		char* newMessage = "TERMINATE CLIENT PROCESS";

		if(operation[0] == '+'){
			if(send(clientSocket, messageAdd,BUFFERSIZE,0) <= 0) {
				ErrorHandler("Error sending operation");
				closesocket(clientSocket);
				clearWinSock();
				system("pause");
				return 0;
			}
		}
		else if(operation[0] == 'x' || operation[0] == '*' || operation[0] == 'X'){
			if(send(clientSocket, messageMolt,BUFFERSIZE,0) <= 0) {
				ErrorHandler("Error sending operation");
				closesocket(clientSocket);
				clearWinSock();
				system("pause");
				return 0;
			}

		} else if (operation[0] == '-'){
			if(send(clientSocket, messageSottr,BUFFERSIZE,0) <= 0) {
				ErrorHandler("Error sending operation");
				closesocket(clientSocket);
				clearWinSock();
				system("pause");
				return 0;
			}

		} else if (operation[0] == '/'){
			if(send(clientSocket, messageDivis,BUFFERSIZE,0) <= 0) {
				ErrorHandler("Error sending operation");
				closesocket(clientSocket);
				clearWinSock();
				system("pause");
				return 0;
			}

		} else if (operation[0] != '+' || operation[0] != '*' || operation[0] != 'x' || operation[0] != 'X' || operation[0] != '-' || operation[0] != '/'){
			if(send(clientSocket, newMessage ,strlen(newMessage),0) <= 0) {
				ErrorHandler("Error sending operation \n");
				closesocket(clientSocket);
				clearWinSock();
				system("pause");
				return 0;
			}
		}else { printf("%s", newMessage);}

		if(operation[0] == '+' || operation[0] =='*' || operation[0] == 'x' || operation[0] == 'X' || operation[0] == '-'  || operation[0] == '/'){

			int numX = 0;
			int numY = 0;

			if (recv(clientSocket, (void*)&numX, sizeof(numX), 0) < 0){
				printf ("Error receiving number X \n");
				closesocket(clientSocket);
				clearWinSock();
				system("pause");
				return 0;
			}
			else{
				printf("\nNumber X received successfully: %d \n",numX);
			}

			if (recv(clientSocket, (void*)&numY, sizeof(numY), 0) <= 0){
				printf ("Error receiving number Y \n");
				closesocket(clientSocket);
				clearWinSock();
				system("pause");
				return 0;
			}
			else{
				printf("\nNumber Y received successfully: %d \n",numY);
			}


			if(operation[0] == '+'){
				result = add(numX,numY);
			} else if (operation[0] == '-'){
				result = sub(numX,numY);
			}else if (operation[0] == 'x'  || operation[0] == 'X' || operation[0] == '*'){
				result = mult(numX,numY);
			}else if (operation[0] == '/'){
				result=division(numX,numY);
			}


			if(send(clientSocket,(void *)&result,sizeof(result),0) < 0) {
				ErrorHandler("error send string");
				closesocket(clientSocket);
				clearWinSock();
				system("pause");
				return 0;
			}
			else
				printf("\n correct result \n");

		}
	}
return 0;
}


	int add(int x, int y){
		return x+y;
	}

	int mult(int x, int y){
		return x*y;
	}

	int sub(int x, int y){
		return x-y;
	}

	int division(int x, int y){
		return x/y;
	}


	void ErrorHandler(char* errorMessage) {
		printf("%s", errorMessage);
	}

	void clearWinSock() {
#if defined WIN32
		WSACleanup();
#endif
	}

	void welcomeMessage(){
		printf("SERVER TCP\n");
	}

