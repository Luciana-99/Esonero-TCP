#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
#endif
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#define BUFFERSIZE 512
#define localhost "127.0.0.1"
#define PROTOPORT 27015

	/*global variables*/
		char operation=' ';
		int x;
		int y;
		int result;


		/* function prototypes */
void ErrorHandler(char* errorMessage);
void clearWinSock();
void welcomeMessage();

int main (int argc, const char** argv){
	welcomeMessage();
#if defined WIN32
	WSADATA wsaData;
	int iResult = WSAStartup(MAKEWORD(2,2), &wsaData);
	if(iResult!=0){
		ErrorHandler("\nWSAStartup () initialization error!");
		clearWinSock();
		system("PAUSE");
		return 0;
	} else {
		printf("[+] WSAStartup initialization successful!\n");
	}
#endif

	/* Creation of the socket */

	int mySocket = socket(PF_INET,SOCK_STREAM,IPPROTO_TCP);
	if(mySocket < 0){
		ErrorHandler("Socket creation failed.\n");
		closesocket(mySocket);
		clearWinSock();
		system("Pause");
		return 0;
	} else {
		printf("[+] Socket created successfully\n");
	}

	/* End creation of the socket */

	/*construction of the server address*/
	/*char ipNumber[20]= "127.0.0.1";
	int portNumber=27015;
	char answer=' ';

	printf("do you want to define port and ip address? (S/N) \n");
	scanf("%c",&answer);
	if(answer=='s' || answer=='S'){
		printf("Please, insert server IP address to connect: ");
		scanf("%s", ipNumber);
		printf("Enter the port number: ");
		scanf("%d", &portNumber);
	}else if(answer!='n'&& answer!='N' && answer!='s' && answer!='S'){
		ErrorHandler ("\nError value\n");
		closesocket(mySocket);
		clearWinSock();

	}*/

	struct sockaddr_in myAddress;
	memset(&myAddress, 0, sizeof(myAddress));
	myAddress.sin_family = AF_INET;
	myAddress.sin_addr.s_addr = inet_addr(localhost);
	myAddress.sin_port= htons(PROTOPORT);
	/*end construction of the server address*/


	/* connection to the server */

	if(connect (mySocket, (struct sockaddr *)&myAddress, sizeof(myAddress)) < 0){
		ErrorHandler ("\nError connecting with the server!\n");
		closesocket(mySocket);
		clearWinSock();
		system("PAUSE");
		return 0;
	}

	char message[BUFFERSIZE] = "";

	if (recv(mySocket, message, BUFFERSIZE - 1, 0) <= 0){
		ErrorHandler("\nError in communication with the Server!\n");
		closesocket(mySocket);
		clearWinSock();
		system("Pause");
		return 0;
	} else	{ printf("%s\n", message);
	}
	fflush(stdin);

	printf("Enter operation and two number:(ES:+ 26 48)\n");
	scanf("%c%d%d",&operation,&x, &y);


	if(operation == '+' || operation=='*' || operation== 'x' || operation == 'X' || operation== '-' || operation == '/'){

		if(send(mySocket,(void*)&operation, sizeof(operation), 0) <= 0) {
				ErrorHandler("Error send string");
				closesocket(mySocket);
				clearWinSock();
				system("Pause");
				return 0;
			} else {printf("Send operation correct..\n");
			}

			char messOperation[BUFFERSIZE] = "";
			if (recv(mySocket, messOperation, BUFFERSIZE, 0) < 0){
				printf ("Error receiving operation result \n");
				closesocket(mySocket);
				clearWinSock();
				system("Pause");
				return 0;
			} else {printf("%s\n", messOperation);
			}


		if(send(mySocket,(void*)&x,sizeof(x),0) < 0) {
			ErrorHandler("Error send number X");
			closesocket(mySocket);
			clearWinSock();
			system("pause");
			return 0;
		}else printf("Send number X correct..\n");


		if(operation== '/' && y==0){
			ErrorHandler("Error send number Y \n");
			closesocket(mySocket);
		}else if(send(mySocket,(void*)&y,sizeof(y),0) < 0) {
			closesocket(mySocket);
			clearWinSock();
			system("pause");
			return 0;
		} else printf("Send number Y correct..\n");

			if (recv(mySocket, (void*)&result, BUFFERSIZE, 0) < 0){
				printf ("Error receiving operation result\n");
				closesocket(mySocket);
				clearWinSock();
				system("Pause");
				return 0;
			} else printf("Result: %d \n",result);

	}
closesocket(mySocket);
clearWinSock();
system("Pause");
return 0;
}

void ErrorHandler(char* errorMessage) {
	printf("%s", errorMessage);
}

void clearWinSock() {
#if defined WIN32
	WSACleanup();
#endif
}

void welcomeMessage(){
	printf("CLIENT TCP\n");
}

