#ifndef PROTOCOL_CLIENT_H_
#define PROTOCOL_CLIENT_H_
#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#define BUFFERSIZE 512
#define PROTOPORT 27015

void ErrorHandler(char *errorMessage) {
		printf(errorMessage);
	}
	void ClearWinSock() {
	#if defined WIN32
		WSACleanup();
	#endif
	}
	int main(void) {
		#if defined WIN32
			WSADATA wsaData;
			int iResult = WSAStartup(MAKEWORD(2 ,2), &wsaData);
			if (iResult != 0) {
				printf ("error at WSASturtup\n");
				return 0;
			}
		#endif

			/* Creation of the socket */
			int Csocket;
			Csocket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
			if (Csocket < 0) {
				ErrorHandler("socket creation failed.\n");
				closesocket(Csocket);
				ClearWinSock();
				return 0;
			}


			/*construction of the server address*/
			struct sockaddr_in sad;
			memset(&sad, 0, sizeof(sad));
			sad.sin_family = AF_INET;
			sad.sin_addr.s_addr = inet_addr("127.0.0.1"); // IP's server
			sad.sin_port = htons(27015); // Server port


			/* connection to the server */
			int conn= connect(Csocket, (struct sockaddr *)&sad, sizeof(sad));
			if (conn < 0)
			{
				ErrorHandler( "Error in communication with the Server\n" );
				system("pause");
				closesocket(Csocket);
				ClearWinSock();
				return 0;
			}
			printf("Client\n\n");


			/*receive string from server*/
			char buff[BUFFERSIZE];
			recv(Csocket,buff,sizeof(buff),0);
			printf("%s\n",buff);
}
#endif /* PROTOCOL_CLIENT_H_ */
